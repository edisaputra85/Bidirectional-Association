package bidirectional11;
public class Sekolah {
    private String namaSekolah;//variabel instance
    private KepalaSekolah kepalaSekolah;//objek kepalaSekolah merupakan atribut pada kelas Sekolah
    
    public Sekolah (String namaSekolah){//Konstruktor
        this.namaSekolah = namaSekolah;
    }
    public String getNamaSekolah(){
        return namaSekolah;
    }
    public void setNamaSekolah(String namaSekolah){
        this.namaSekolah = namaSekolah;
    }
    public KepalaSekolah getKepalaSekolah(){ //method getter untuk objek kepalaSekolah
        return kepalaSekolah;
    }
    public void setKepalaSekolah(KepalaSekolah kepalaSekolah){//method setter untuk objek kepalaSekolah
        this.kepalaSekolah = kepalaSekolah;
    }    
}
