package bidirectional11;
public class Bidirectional11 {
    public static void main(String[] args) {
        //instansiasi objek
        Sekolah sekolah = new Sekolah ("SMAN Titian Teras");
        KepalaSekolah kepalaSekolah = new KepalaSekolah("Pak Pahrin");
        
        //association bidirectional terjadi di sini
        //kita menempatkan objek kepalaSekolah sebagai atribut pada setKepalaSekolah
        sekolah.setKepalaSekolah(kepalaSekolah); 
        kepalaSekolah.setSekolah(sekolah);
        
        //memunculkan nilai dari objek sekolah
        System.out.println(sekolah.getNamaSekolah());
        //namaKepalaSekolah sebagai atribut pada objek kepalaSekolah; 
        //dan kepalaSekolah sebagai atribut pada objek sekolah.
        System.out.println(sekolah.getKepalaSekolah().getNamaKepalaSekolah());
                   
        //memunculkan nilai dari objek kepalaSekolah
        System.out.println(kepalaSekolah.getNamaKepalaSekolah());
        System.out.println(kepalaSekolah.getSekolah().getNamaSekolah());       
    }   
}
