package bidirectional1m;
import java.util.LinkedList;

public class Bidirectional1M {

    public static void main(String[] args) {
        //membuat objek mahasiswa berupa collection
        LinkedList<Mahasiswa> mhs = new LinkedList<>();
        Prodi prodi = new Prodi("Sistem Informasi",mhs);//perintah yang menciptakan relasi
        
        //association one to many
        mhs.addFirst(new Mahasiswa("F1E119040",prodi));//perintah yang menciptakan relasi
        mhs.addFirst(new Mahasiswa("F1E119041",prodi));
        
        System.out.println("List Mahasiswa " + prodi.getNamaProdi());
        System.out.println("====================================");
        for (Mahasiswa listMhs : prodi.getMahasiswa()){
            System.out.println(listMhs.getNIM());
        }
    }  
}
