package bidirectional1m;
import java.util.LinkedList;
public class Prodi {
    private String namaProdi;
    private LinkedList<Mahasiswa> mahasiswa;
    
    public Prodi (String namaProdi,LinkedList<Mahasiswa> mahasiswa){
        this.namaProdi=namaProdi;
        this.mahasiswa = mahasiswa;
    }
    
    public String getNamaProdi(){
        return namaProdi;
    }
    public void setNamaProdi(String namaProdi){
        this.namaProdi=namaProdi;
    }
    
    public LinkedList<Mahasiswa> getMahasiswa(){
        return mahasiswa;
    }
    public void setMahasiswa(LinkedList<Mahasiswa> mahasiswa){
        this.mahasiswa=mahasiswa;
    }   
}
