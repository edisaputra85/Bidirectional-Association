package bidirectionalmm;
public class Mahasiswa {
    private String nim;    
    public Mahasiswa(String nim){
        this.nim = nim;
    }
    
    public String getNIM(){
        return nim;
    }
    public void setNIM(String nim){
        this.nim = nim;
    }
}
