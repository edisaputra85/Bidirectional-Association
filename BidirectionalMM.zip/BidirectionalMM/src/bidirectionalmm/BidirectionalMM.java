package bidirectionalmm;
public class BidirectionalMM {
    public static void main(String[] args) {
        KRS krs = new KRS();
        //menambahkna mahasiswa
        krs.addMahasiswa("F1E119001");
        krs.addMahasiswa("F1E119002");
        krs.addMahasiswa("F1E119003");
        //menambahkan matakuliah
        krs.addMatakuliah("Pemrograman Berorientasi Objek", "DSI334", 2);
        krs.addMatakuliah("Praktikum Pemrograman Berorientasi Objek", "LSI334", 1);
        
        krs.mappingKRS(krs.mhs.get(0), krs.mk.get(0));
        krs.mappingKRS(krs.mhs.get(0), krs.mk.get(1));
        
        krs.mappingKRS(krs.mhs.get(1), krs.mk.get(1));
        krs.mappingKRS(krs.mhs.get(2), krs.mk.get(1));  
    }
}
